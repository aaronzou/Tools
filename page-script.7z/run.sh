list=./test-list.txt
out=./../result.html
tmp=template.html

nol=$(wc -l < "$list")
sed -n -e "s|NNN|$nol|g;1,6p" $tmp > $out

counter=0
while read name
do
	name=$(echo $name|tr -d '\r\n')
	echo $name

	sed -n -e "s|III|$counter|g;s|XXX|$name|g;7,21p" $tmp >> $out

	counter=$[$counter+1]
done <$list
sed -n "22,$ p" $tmp >> $out
